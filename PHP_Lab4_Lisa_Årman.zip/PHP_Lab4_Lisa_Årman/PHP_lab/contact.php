<!doctype html>

<html>
	<head>
		<title>Lab1</title>
		<link rel="stylesheet" type="text/css" href="css.css">
		<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Oswald:400,500,600" rel="stylesheet">
	</head>
	

	<body>
		<?php include ('header.php'); ?>		
	<div id="wrapper">

		<div id="cform">
			<form id="form">
  				Name:<br>
 				<input type="text" name="firstname"><br>
  				Email:<br>
  				<input type="text" name="lastname"><br>
  				Message:<br>
  				<input id="message" type="text" name="lastname"><br>
  				<input type="submit" value="Submit">
  				
			</form>
		</div>
	</div>	
	<?php include ('footer.php'); ?>	
	</body>
</html>