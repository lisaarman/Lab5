
<?php
include("config.php");
$title = "Search books";
include("header.php");
?><head>
	<link rel="stylesheet" type="text/css" href="css.css">	
</head>

<div class="wrapper">
<div id="first">
<h3>Search our Book Catalog</h3>
	<p>You may search by title, or by author, or both</p>
<form action="listBooks.php" method="POST">
    <table id="search" bgcolor="#dddddd" cellpadding="6">
        <tbody>
            <tr>
                <td>Title:</td>
                <td><INPUT type="text" name="searchtitle"></td>
            </tr>
            <tr>
                <td>Author:</td>
                <td><INPUT type="text" name="searchauthor"></td>
            </tr>
            <tr>
                <td></td>
                <td><INPUT id="submit" type="submit" name="submit" value="Submit"></td>
            </tr>
        </tbody>
    </table>
</form>
	</div>
<div id="second">
<h3>Book List</h3>

<?php
# This is the mysqli version

$searchtitle = "";
$searchauthor = "";
	
# Open the database
@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

//IF there's something in the form
if (isset($_POST) && !empty($_POST)) {
# Get data from form
	//remove mellanslag
    $searchtitle = trim($_POST['searchtitle']);
    $searchauthor = trim($_POST['searchauthor']);
	
	$searchtitle = mysqli_real_escape_string($db, $searchtitle);
	$searchauthor = mysqli_real_escape_string($db, $searchauthor);
	
	$uname = htmlentities($_POST['searchtitle']);
	$uname = htmlentities($_POST['searchauthor']);
}

//	if (!$searchtitle && !$searchauthor) {
//	  echo "You must specify either a title or an author";
//	  exit();
//	}


$searchtitle = addslashes($searchtitle);
$searchauthor = addslashes($searchauthor);


//IF the database can't connect
if ($db->connect_error) {
    echo "could not connect: " . $db->connect_error;
    printf("<br><a href=index.php>Return to home page </a>");
    exit();
}

# Build the query. Users are allowed to search on title, author, or both
 
//connects the columns to the search function. Makes it possible to write a part
//of the title or author
$query = "SELECT bookid, title, author, reserved FROM book";
if ($searchtitle && !$searchauthor) { // Title search only
    $query = $query . " where title like '%" . $searchtitle . "%'";
}
if (!$searchtitle && $searchauthor) { // Author search only
    $query = $query . " where author like '%" . $searchauthor . "%'";
}
if ($searchtitle && $searchauthor) { // Title and Author search
    $query = $query . " where title like '%" . $searchtitle . "%' and author like '%" . $searchauthor . "%'"; // unfinished
}

//echo "Running the query: $query <br/>"; # For debugging


  # Here's the query using an associative array for the results
//$result = $db->query($query);
//echo "<p> $result->num_rows matching books found </p>";
//echo "<table border=1>";
//while($row = $result->fetch_assoc()) {
//echo "<tr><td>" . $row['bookid'] . "</td> <td>" . $row['title'] . "</td><td>" . $row['author'] . "</td></tr>";
//}
//echo "</table>";
 
# Here's the query using bound result parameters
    // echo "we are now using bound result parameters <br/>";
    $stmt = $db->prepare($query);
//takes the result of the search and create variables from it
    $stmt->bind_result($bookid, $title, $author, $reserved);
    $stmt->execute();

    echo '<table bgcolor="#dddddd" cellpadding="6">';
    echo '<tr id="headings"><b><td>Title</td> <td>Author</td> <td>Reserved?</td> </b> </tr>';
    while ($stmt->fetch()) {
		if ($reserved == 0) 
			$reserved = "NO";
		else $reserved ="YES";
        echo "<tr>";
        echo "<td> $title </td><td> $author </td><td> $reserved </td>";
        echo '<td><a id="reserveText" href="reserveBook.php?bookid=' . urlencode($bookid) . '"> Reserve </a></td>';
        echo "</tr>";
    }
    echo "</table>";
    ?>
	</div>
</div>

<?php include("footer.php"); ?>




<style>
	#reserveText {
		text-decoration: none;
		background: #606060;
		padding: 4px 5px;
		color: white;
		
	}
	#headings {
		font-family: 'oswald';
		font-size: 19px;
		color: #404040;
		font-weight: bold;
	}
	#search {
		margin: 10px 0;
		padding: 6px;
	}
	#search #submit {
		background: white;
		border: 0.2px solid #dddddd;
		padding: 4px 4px;
		color: #404040;
	}
	#search td input{
		border: none;
		font-family: "open sans";
	}
	.wrapper {
		max-width: 1600px;
		margin: 0 auto;
		min-height: 95vh;
		padding: 0 16px;
	}
	h3 {
		display: inline-block;
	}
	#first {
		width: 50%;
		float: left;
		padding-left: 6px;
		box-sizing: border-box;
		padding-top: 36px;
	}
	#second {
		width: 50%;
		float: left;
		padding-left: 6px;
		box-sizing: border-box;
		padding-top: 36px;
	}
	p {
		margin: 0;
		padding: 0;
	}
</style>