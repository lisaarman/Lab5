<head>
	<?php include ('config.php'); ?>
</head>
	<div class="headimg">>
		<img src="img/bokcrop.jpg"/>
	</div>
	<nav>
		<div id="ulwrapper">
			<ul>
				<a href="index.php"><li class="<?php echo ($current_page == 'index.php' || $current_page == '') ? 'active' : NULL ?>" 
				>Home</li></a>
				<a href="about.php"><li class="<?php echo ($current_page == 'about.php') ? 'active' : NULL ?>" 
				>About Us</li></a>
				<a href="listBooks.php"><li class="<?php echo ($current_page == 'listBooks.php') ? 'active' : NULL ?>">Browse Books</li></a>
				<a href="reservedBooks.php"><li class="<?php echo ($current_page == 'reservedBooks.php') ? 'active' : NULL ?>">My Books</li></a>
				<a href="contact.php"><li id="con" class="<?php echo ($current_page == 'contact.php') ? 'active' : NULL ?>">Contact</li></a>
				<a href="gallery.php"><li id="con" class="<?php echo ($current_page == 'gallery.php') ? 'active' : NULL ?>">Gallery</li></a>
			</ul>
		</div>
	</nav>
	
<style>
	.headimg img {
		max-width: 100%;
	}
	#ulwrapper {
	max-width: 1600px;
	margin: 0 auto;
	padding: 0;
	text-align: right;
	}
	li {
	list-style-type: none;
	margin-right: 30px;
	font-size: 16px;
	font-family: "open sans";
	font-weight: 500;
	padding-top: 25px;
	margin-bottom: 18px;
	padding-bottom: 1px;
	text-align: center;
	display: inline-block;
}

	ul {
	text-decoration: none;
	padding: 0px;
	margin: 0 auto;
	top: 40px;
	overflow: hidden;
	z-index: 100;
}

	nav {
	text-align: center;
	background: white;
	position: fixed;
	top: -1px;
	float: right;
	width: 100%;
	z-index: 999;
}
	a {
	color: #000000;
}
	.active {
		border-bottom: 3px solid #9E0002;
	}
	ul a:hover {
	color: #535353;
}
	.headimg {
		overflow: hidden;
		padding: 0;
		margin: 0;
		background-color: rgba(248, 247, 216, 0.7);
		max-width: 1600px;
		margin: 0 auto
}
</style>