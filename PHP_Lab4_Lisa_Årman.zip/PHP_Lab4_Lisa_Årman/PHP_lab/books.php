<!doctype html>
<html>
	<head>
		<title>Lab1</title>
		<link rel="stylesheet" type="text/css" href="css.css">
		<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Oswald:400,500,600" rel="stylesheet">
		<?php include ('config.php'); ?>
	</head>
	<body>
	<?php include ('header.php'); ?>
	<div id="wrapper">
		<h3 id="my">My Books</h3>
		<ul id="my_books_list">
					<li>
						<div class="mybooks_title">
							<h5>
								A God in Ruins
							</h5>
							<p>
								Anne Tyler
							</p>
						</div>
						<div class="returndate">
							<p >
							Return date:
							</p>
							<p>
								13/9 2017
							</p>
						</div>
						<div class="returnbutton">
							RETURN
						</div>
					</li>
					<li>
						<div class="mybooks_title">
							<h5>
								A Dog in Ruins
							</h5>
							<p>
								Kate Atkinson
							</p>
						</div>
						<div class="returndate">
							<p >
							Return date:
							</p>
							<p>
								13/9 2017
							</p>
						</div>
						<div class="returnbutton">
							RETURN
						</div>
					</li>
				</ul>
		
		
	</div>
	<?php include ('footer.php'); ?>
	</body>
</html>


<style>

	#my_books_list {
		padding-left: 88px;
	}
	#my_books_list li {
	list-style: none;
	overflow: hidden;
	margin: 10px 0;
	padding-bottom: 30px;
		width: 100%;
}
.mybooks_title {
	float: left;
}
.mybooks_title h5 {
	color: #9E0002;
	font-family:"open sans", "sans-serif";
	font-size: 14pt;
	padding: 0;
	margin: 0;
}
.mybooks_title p {
	padding: 0;
	margin: 0;
	font-size: 10pt;
	margin-top: 5px;
	text-align: left;
}
.returndate {
	float: left;
	padding: 0;
	margin: 0;
	font-size: 10pt;
	margin-top: 26px;
	margin-left: 200px;
}
.returndate p {
	margin: 0 30px;
	padding: 0;
}
.returnbutton {
	width: 100px;
	background-color: #404040;
	text-align: center;
	padding: 10px;
	font-family: "open sans", "sans-serif";
	float: left; 
	margin-top: 20px;
	margin-left: 30px;
	color: white;
}
.returnbutton:hover {
	background-color: #9E0002;
}
	#my {
		padding-left: 88px;
		padding-top: 5vh;
	}

</style>