<!doctype html>
<html>
	<head>
		<title>Lab1</title>
		<link rel="stylesheet" type="text/css" href="css.css">
		<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Oswald:400,500,600" rel="stylesheet">
		
	</head>
	<body>
	<?php include ('header.php'); ?>
	<div id="wrapper">
		<!--<h2 id="browse">Browse Books</h2>-->
		<h3>Use your search</h3>
            <form id="search" action="browse.php" method="GET">
                <table cellpadding="6">
                    <tbody>
                        <tr>
                            <td>Title:</td>
                            <td><INPUT type="text" name="searchtitle"></td>
                        </tr>
                        <tr>
                            <td>Author:</td>
                            <td><INPUT type="text" name="searchauthor"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><INPUT id="submit" type="submit" name="submit" value="Submit"></td>
                        </tr>
                    </tbody>
                </table>
            </form>
		<?php
			$books = array();
			$books[] = array("title" => "What Happened", "author" => "Hillary Rodham Clinton");
			$books[] = array("title" => "It: A Novel", "author" => "Stephen King");
			$books[] = array("title" => "Beartown: A Novel", "author" => "Fredrik Backman");
			$books[] = array("title" => "Exit West: A Novel", "author" => "Mohsin Hamid");	
				
            if (isset($_GET) && !empty($_GET)) {
			//check if the submit button has been pressed	
				                
                $searchtitle = trim($_GET['searchtitle']);
                $searchauthor = trim($_GET['searchauthor']);
				//first trim the search (remove white psace)

                $searchtitle = addslashes($searchtitle);
                $searchauthor = addslashes($searchauthor);   //adds slashes if there's an apostrophe or quotation mark           
                
                $id = array_search($searchtitle, array_column($books, 'title'));
				$id2 = array_search($searchauthor, array_column($books, 'author'));
				//here we create a variable $id and basically say that we want the data from the array matching the search criteria

                echo '<table cellpadding="6">';
                echo '<tr><b><td class="heading">Title</td> <td class="heading">Author</td> <td></td> </b> </tr>';
				//echo $id;
				
                
                if ($id !== FALSE) {
					//now we check if we have the ID or not in our array. If the search was a hit, it will assign something to our DB, if not, then it will not work.
                    $book = $books[$id];
                    $title = $book['title'];
                    $author = $book['author'];
                    echo "<tr>";
                    echo "<td> $title </td><td> $author </td>";
                    echo '<td><a href="reserve.php?reservation=' .  urlencode($title) . '"> Reserve </a></td>';
                    echo "</tr>";
                }
				elseif ($id2 !== FALSE) {
					//now we check if we have the ID or not in our array. If the search was a hit, it will assign something to our DB, if not, then it will not work.
                    $book = $books[$id2];
                    $title = $book['title'];
                    $author = $book['author'];
                    echo "<tr>";
                    echo "<td> $title </td><td> $author </td>";
                    echo '<td><a href="reserve.php?reservation=' .  urlencode($title) . '"> Reserve </a></td>';
                    echo "</tr>";
                }
                echo "</table>";
            } 
            
            //the IF statement above is used to check if the GET metod is set, if it has displayed the results of the search. If it not has been set, the whole list will be displated instead 
				
            //??
            
            # if they have not been set, just display the list instead. In this case "book-list" is insufficient
            # all you have to do is merge book-list.php with book-search.php and create one master page
            # define the array at the start in PHP and manipulate it later on.
            
			//?	
				
            else 
            //this ELSE statement basically just how the book-list    
                {                
                echo '<table cellpadding="6">';
                echo '<tr><b><td>Title</td> <td>Author</td> <td></td> </b> </tr>';
                foreach ($books as $book) {
                    $title = $book['title'];
                    $author = $book['author'];
                    echo "<tr>";
                    echo "<td> $title </td><td> $author </td>";
                    echo '<td><a href="reserve.php?reservation=' . urlencode($title) . '"> Reserve </a></td>';
                    echo "</tr>";
                }
                echo "</table>";
            }
            ?>
		
		
	</div>
		<?php include ('footer.php'); ?>
	</body>
	<style>
		#reserve {
			text-decoration: none;
			background: #404040;
			padding: 4px 6px;
			color: white;
			font-size: 15px;
		}
		table {
			font-family: "open sans";
			padding-top: 12vh;
			padding-left: 88px;
		}
		.heading {
			font-family: "oswald";
			font-size: 22px;
			color: #9E0002;
		}
		td {
			padding-right: 124px;
		}
		#browse {
			color: black;
			font-family: "oswald";
			font-size: 26px;
			padding-left: 88px;
			padding-top: 5vh;
			margin: 0 auto;
		}
	</style>
</html>