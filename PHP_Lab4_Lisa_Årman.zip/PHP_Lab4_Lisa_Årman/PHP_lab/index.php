<!doctype html>
<html>
	<head>
		<title>Lab1</title>
		<link rel="stylesheet" type="text/css" href="css.css">
		<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Oswald:400,500,600" rel="stylesheet">
	</head>
	<body>
		<div id="start">
			<?php include ('header.php'); ?>
		</div>
		<img id="bigimg" src="img/bok.jpg"/>
		<div id="welcometext">
		<h2 id="discover">Discover</h2>
			<h1 id="world">A WORLD FULL OF BOOKS</h1>
		</div>
		<div id="arrow">
			<i class="arrow down"></i>
		</div>
	<div class="wrapper">
	
	<div id="newsWrap">
		<div class="news">
			<h3>Nyhet1</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nulla elit, cursus sed arcu eu, ornare convallis dui. Praesent suscipit tempus lacus, et accumsan maur ullamcorper ut. Phasellus eget sodales massa, non am vehicula ex. Aenean non dapibus libero, id feugiat felis. Aenean nisi sem, auctor a justo vel justo vel.</p>
		</div>
		<div class="news">
			<h3>Nyhet2</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nulla elit, cursus sed arcu eu, ornare convallis dui. Praesent suscipit tempus lacus, et accumsan maur ullamcorper ut. Phasellus eget sodales massa, non am vehicula ex. Aenean non dapibus libero, id feugiat felis. Aenean nisi sem, auctor a justo vel justo vel.</p>
		</div>
		<div class="news">
			<h3>Nyhet3</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nulla elit, cursus sed arcu eu, ornare convallis dui. Praesent suscipit tempus lacus, et accumsan maur ullamcorper ut. Phasellus eget sodales massa, non am vehicula ex. Aenean non dapibus libero, id feugiat felis. Aenean nisi sem, auctor a justo vel justo vel.</p>
		</div>
		<div class="news">
			<h3>Nyhet4</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nulla elit, cursus sed arcu eu, ornare convallis dui. Praesent suscipit tempus lacus, et accumsan maur ullamcorper ut. Phasellus eget sodales massa, non am vehicula ex. Aenean non dapibus libero, id feugiat felis. Aenean nisi sem, auctor a justo vel justo vel.</p>
		</div>
	</div>
		</div>
		<?php include ('footer.php'); ?>
	</body>
</html>