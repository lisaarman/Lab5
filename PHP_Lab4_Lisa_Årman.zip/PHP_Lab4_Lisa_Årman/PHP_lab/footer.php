<div id="footer">
	<div id="footCont">
		<p>lorenewiorhsfrgg</p>
	</div>
</div>


<style>
	#footer {
		width: 100%;
		background: #404040;
		min-height: 30px;
		bottom: 0px;
		position: fixed;
	}
	#footCont {
		max-width: 1800px;
		margin: 0 auto;
		padding-left: 5vh;
		padding-top: 6px;
		padding-bottom: 6px;
	}
	h4 {
		font-family: "oswald";
		color: white;
		font-size: 20px;
		margin: 0;
	}
	#footer p {
		color: white;
	}
	p {
		font-family: "open sans";
		margin: 0;
	}
</style>