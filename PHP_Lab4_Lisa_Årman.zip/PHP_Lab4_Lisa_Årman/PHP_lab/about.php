<!doctype html>
<html>
	<head>
		<title>Lab1</title>
		<link rel="stylesheet" type="text/css" href="css.css">
		<link href="https://fonts.googleapis.com/css?family=Dancing+Script|Oswald:400,500,600" rel="stylesheet">
	</head>
	<body>
	<?php include ('header.php'); ?>
	<div id="wrapper">
	<div id="aboutCont">
		<img id="window" src="img/libary.jpg"/>
		<div id="aboutText">
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nulla elit, cursus sed arcu eu, ornare convallis dui. Praesent suscipit tempus lacus, et accumsan mauris ullamcorper ut. Phasellus eget sodales massa, non vehicula ex. Aenean non dapibus libero, id feugiat felis. Aenean nisi sem, auctor a justo vel, lobortis venenatis nisl. Proin ut feugiat tellus.<br><br> Vestibulum congue libero ut augue dictum, a pretium ipsum pretium. Morbi at felis tellus. Maecenas a purus magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nulla elit, cursus sed arcu eu, ornare convallis dui. Praesent suscipit tempus lacus, et accumsan mauris ullamcorper ut. Phasellus eget sodales massa, non vehicula ex. Aenean non dapibus libero, id feugiat felis. Aenean nisi sem, auctor a justo vel, lobortis venenatis nisl. Proin ut feugiat tellus.<br><br> Vestibulum congue libero ut augue dictum, a pretium ipsum pretium. Morbi at felis tellus. Maecenas a purus magna.</p>
		</div>
	</div>
		</div>
	<?php include ('footer.php'); ?>
	</body>
</html>