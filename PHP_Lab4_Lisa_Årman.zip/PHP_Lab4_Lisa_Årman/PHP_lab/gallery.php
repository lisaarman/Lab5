<?php
include("config.php");
$title = "Search books";
include("header.php");
?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css.css">	
</head>
<body>
	<div class="wrapper">
		<div id="first">
			<h3>Gallery</h3>
		</div>
		
		<ul id="imgList">
    <?php
    /*Added a loop that iterates through the img folder, and adds each element into the img list*/
    $dir = new DirectoryIterator("uploadedFiles");
    foreach ($dir as $img) {
        if (!$img->isDot()) {//checks if a entry is a "." or ".." and will in that case not include it.
          echo "<li><img src=\"uploadedFiles/" . $img->getFilename() . "\"></li>";
        }
    }
    ?>
  </ul>
		
	</div>
	<?php include ('footer.php'); ?>
</body>
</html>


<style>
	#imgList li {
		max-width: 50%;
		box-sizing: border-box;
	}
	#imgList img {
		max-width: 100%;
	}
</style>